import gradio as gr
from fish_speech.models import FishModel

model = FishModel.from_pretrained("fish2023/fish-small-uk")

def transcribe_audio(file):
    result = model.transcribe(file.name)
    return result["text"]

iface = gr.Interface(
    fn=transcribe_audio,
    inputs=gr.Audio(type="filepath"),
    outputs=gr.Textbox(),
    title="Fish-Speech-UK Transcriber",
    description="Ukrainian Speech-to-Text модель на основі FishModel"
)

iface.launch()
# 🐟 Fish-Speech-UK Transcriber

🎤 **Fish-Speech-UK** — це українська модель автоматичного розпізнавання мовлення (ASR), заснована на бібліотеці [fish-speech](https://github.com/fishaudio/fish-speech).

Цей HuggingFace Space дозволяє транскрибувати українське мовлення в текст просто через веб-інтерфейс!

---

## 🚀 Як користуватись

1. Натисни "Завантажити аудіо" і обери `.wav`, `.mp3` або інший файл.
2. Зачекай, поки модель розпізнає текст.
3. Скопіюй результат зі зручного вікна транскрипції.

---

## 🧠 Технології

- Модель: `fish2023/fish-small-uk`
- Фреймворк: `gradio`
- Мова: 🇺🇦 Українська

---

## 🔧 Локальне розгортання (опційно)

```bash
git clone https://github.com/fishaudio/fish-speech.git
pip install git+https://github.com/fishaudio/fish-speech.git
pip install ffmpeg-python phonemizer gradio
python app.py
```

---

## 📄 Автор

👤 Розробка та адаптація: **Богдан**  
📧 Питання/пропозиції: через Issues або Pull Request